# codespace-resume-hosted
Example of hosting a static website on GitHub pages

# Author
Justin@codespace.co.za

# Wireframe Link:
https://somelink/
